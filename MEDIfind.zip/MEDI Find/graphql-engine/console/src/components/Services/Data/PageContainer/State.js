const defaultState = {
  username: 'Guest User',
};

export default defaultState;
