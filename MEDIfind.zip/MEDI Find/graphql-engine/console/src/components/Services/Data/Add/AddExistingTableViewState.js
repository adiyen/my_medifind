const defaultState = {
  tableName: null,
  ongoingRequest: false,
  lastError: null,
  lastSuccess: null,
};

export default defaultState;
