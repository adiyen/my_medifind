const dataHeaders = currentState => {
  return currentState().tables.dataHeaders;
};
export default dataHeaders;
