const defaultState = {
  percent: 0,
  intervalTime: 200,
  ongoingRequest: false,
  requestSuccess: null,
  requestError: null,
  modalOpen: false,
  error: null,
  isNotifExpanded: false,
  notifMsg: null,
};
export default defaultState;
